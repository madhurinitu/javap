package com.capgemini.mobile.dao;

public @interface override {

}
