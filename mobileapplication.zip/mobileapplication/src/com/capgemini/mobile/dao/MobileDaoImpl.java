package com.capgemini.mobile.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.mobile.bean.Customer;
import com.capgemini.mobile.bean.Mobile;

public class MobileDaoImpl implements ImobileDao
{
	@Override
	public String display()
	{
		
		
	return "demo for mobile app";
	}
	@Override
	public  List<Mobile> getMobileByPrice(double price )
	{
		
		
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			String user ="system";
			String pass="Capgemini123";
			Connection con=DriverManager.getConnection(url,user,pass);
					String sql="select*from mobiles where price >=?";
					PreparedStatement ps=con.prepareStatement(sql);
					ps.setDouble(1,price);
					ResultSet rs=ps.executeQuery();
					Mobile m=null;
					List<Mobile> list= new ArrayList<>();
					while(rs.next())
					{
						m=new Mobile();
						m.setMobileid(rs.getInt(1));
						m.setName(rs.getString(2));
						m.setPrice(rs.getDouble(3));
						m.setQuantity(rs.getString(4));
						list.add(m);
					}			
		return list;
		}
		catch(Exception e){	}
		return null;
	}
	
		public List<Mobile> getAllMobiles()
		{
			try
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				String url="jdbc:oracle:thin:@localhost:1521:XE";
				String user ="system";
				String pass="Capgemini123";
				Connection con=DriverManager.getConnection(url,user,pass);
						String sql="select*from mobiles";
						PreparedStatement ps=con.prepareStatement(sql);
						ResultSet rs=ps.executeQuery();
						Mobile m=null;
						List<Mobile> list= new ArrayList<>();
						while(rs.next())
						{
							m=new Mobile();
							m.setMobileid(rs.getInt(1));
							m.setName(rs.getString(2));
							m.setPrice(rs.getDouble(3));
							m.setQuantity(rs.getString(4));
							list.add(m);
						}			
			return list;
			}
			catch(Exception e){	}
			return null;	
		}
	public	List<Mobile> deleteMobiles(int mobileid)
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			String user ="system";
			String pass="Capgemini123";
			Connection con=DriverManager.getConnection(url,user,pass);
					String sql="delete from  mobiles where mobileid >=?";
					PreparedStatement ps=con.prepareStatement(sql);
		            ps.setInt(1, mobileid);	
		            ps.executeQuery();
		}
		catch(Exception e){	}
		return null;	
	}
	public List<Customer> insertCustomers(String customername, String mailid,long phonenumber)
			{
		
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			String user ="system";
			String pass="Capgemini123";
			Connection con=DriverManager.getConnection(url,user,pass);
					String sql="insert into customer  values(&Customername,& mailid ,& phonenumber)>=???;";
					PreparedStatement ps=con.prepareStatement(sql);
					ps.setString(3,customername);
					ps.setString(3,mailid);
					ps.setLong(3,phonenumber);
					//ps.setDate(4,date);
					
					ResultSet rs=ps.executeQuery();
					Customer c=null;
					List<Customer> list= new ArrayList<>();
					while(rs.next())
					{
						c=new Customer();
						c.setCustomername(rs.getString(1));
						c.setMailid(rs.getString(2));
						c.setPhonenumber(rs.getLong(3));
					//	c.setdate(rs.getString(4));
						list.add(c);
					}			
		return list;
		}
		catch(Exception e){	}
		return null;	
	}
	@Override
	public List<Mobile> updateMobiles()
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			String user ="system";
			String pass="Capgemini123";
			Connection con=DriverManager.getConnection(url,user,pass);
					String sql="UPDATE mobileset quantity=quantity-? where mobileid=?";
					PreparedStatement ps=con.prepareStatement(sql);
					ResultSet rs=ps.executeQuery();
					Mobile m=null;
					List<Mobile> list= new ArrayList<>();
					while(rs.next())
					{
						m=new Mobile();
						m.setMobileid(rs.getInt(1));
						m.setName(rs.getString(2));
						m.setPrice(rs.getDouble(3));
						m.setQuantity(rs.getString(4));
						list.add(m);
					}			
		return list;
		}
		catch(Exception e){	}
		return null;


	}
		
	
}

