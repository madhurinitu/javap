package com.capgemini.mobile.bean;

import java.sql.Date;
import java.time.LocalDate;

public class Customer
{
private String Customername;
private String mailid;
private long  phonenumber;
private Date date;
public String getCustomername() {
	return Customername;
}
public void setCustomername(String customername) {
	Customername = customername;
}
public String getMailid() {
	return mailid;
}
public void setMailid(String mailid) {
	this.mailid = mailid;
}
public long getPhonenumber() {
	return phonenumber;
}
public void setPhonenumber(long phonenumber) {
	this.phonenumber = phonenumber;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}
	

}
