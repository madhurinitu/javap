package com.capgemini.mobile.service;

import java.sql.Date;
import java.util.List;

import com.capgemini.mobile.bean.Customer;
import com.capgemini.mobile.bean.Mobile;

public interface ImobileService 
{
public String display();
public  List<Mobile> getMobileByPrice(double price );
public List<Mobile> getAllMobiles();
public List<Mobile> deleteMobiles(int mobileid);
public List<Customer> insertCustomers(String Customername,String mailid, long  phonenumber);
public List<Mobile> updateMobiles();

}
