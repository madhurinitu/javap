package com.capgemini.mobile.service;

import java.sql.Date;
import java.util.List;

import com.capgemini.mobile.bean.Customer;
import com.capgemini.mobile.bean.Mobile;
import com.capgemini.mobile.dao.ImobileDao;
import com.capgemini.mobile.dao.MobileDaoImpl;

public class MobileserviceImpl implements ImobileService
{
	ImobileDao dao=new MobileDaoImpl();
	
	
	
	@Override
public String display()
	{
		
	return dao.display();
}
	@Override
	public  List<Mobile> getMobileByPrice(double price ){
		return dao.getMobileByPrice(price);
	}
		@Override
		public List<Mobile> getAllMobiles()
		{
		return dao.getAllMobiles();
		}
		@Override
		public List<Mobile> deleteMobiles(int mobileid)
		{
		return dao.deleteMobiles( mobileid);
		}
		@Override
		public List<Customer> insertCustomers(String Customername,String mailid, long  phonenumber)
		{
			return dao.insertCustomers( Customername, mailid,   phonenumber);
		}
		@Override
		public List<Mobile> updateMobiles()
		{
			return dao.updateMobiles();
		}
		
		
		
	}
		

