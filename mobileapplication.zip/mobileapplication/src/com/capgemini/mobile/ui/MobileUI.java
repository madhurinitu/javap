package com.capgemini.mobile.ui;

import java.util.List;
import java.util.Scanner;

import com.capgemini.mobile.bean.Customer;
import com.capgemini.mobile.bean.Mobile;
import com.capgemini.mobile.dao.ImobileDao;
import com.capgemini.mobile.dao.MobileDaoImpl;
import com.capgemini.mobile.service.ImobileService;
import com.capgemini.mobile.service.MobileserviceImpl;

public class MobileUI 
{
public static void main(String[] args)
{
	
	ImobileService service=new MobileserviceImpl();
	System.out.println(service.display());
	Scanner sc=new Scanner(System.in);
	while(true)
	{
		System.out.println("1. insert");
		System.out.println("2. update");
		System.out.println("3.view");
		System.out.println("4. delete");
		System.out.println("5. search");
		System.out.println("6. exit");
		System.out.println("enter your choice");
		int choice =sc.nextInt();
		switch(choice)
		{
		case 1:
			
			
			List<Customer> list3 =service.insertCustomers("madhuri","madhurinitu@gmail.com",77949);
			for(Customer c: list3)
			{
			System.out.println("Customername: "+c.getCustomername());	
		System.out.println("mailid: "+c.getMailid());
		System.out.println("phonenumber: "+c.getPhonenumber());
		//System.out.println("date: "+m.getdate());
		System.out.println("--------------------------------");
		
			}
			
			
			
			
			break;
		case 2:
			List<Mobile> list4 =service.updateMobiles();
			for(Mobile m: list4)
			{
			System.out.println("id: "+m.getMobileid());	
		System.out.println("nmae: "+m.getName());
		System.out.println("price: "+m.getPrice());
		System.out.println("quantity: "+m.getQuantity());
		System.out.println("--------------------------------");
			}
			break;
		case 3:
			List<Mobile> list1 =service.getAllMobiles();
			for(Mobile m: list1)
			{
			System.out.println("id: "+m.getMobileid());	
		System.out.println("nmae: "+m.getName());
		System.out.println("price: "+m.getPrice());
		System.out.println("quantity: "+m.getQuantity());
		System.out.println("--------------------------------");
		
			}
			break;
		case 4:
		{
			System.out.println("enter mobileid");
			int mobileid=sc.nextInt();
			service.deleteMobiles(mobileid);
		System.out.println("----------------deleted--------");	
			}
		break;
		case 5:
		System.out.println("enter price");
		double price=sc.nextDouble();
		
			List<Mobile> list=service.getMobileByPrice(2000);
			for(Mobile m: list)
			{
			System.out.println("id: "+m.getMobileid());	
		System.out.println("nmae: "+m.getName());
		System.out.println("price: "+m.getPrice());
		System.out.println("quantity: "+m.getQuantity());
		System.out.println("--------------------------------");
		}
		break;
		
		case 6:
		System.out.println("exit");
		System.exit(0);
		break;
		default:System.out.println("invalid choice");
		}
	
	}
	
}
}
	



